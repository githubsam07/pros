export const SupportData = `In case of any issues with registration or website you can contact us at
takshashila@citchennai.net
General Queries (+91 94449 88873)
Events (+91 90809 68635)`